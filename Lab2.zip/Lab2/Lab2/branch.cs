﻿using lab2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2
{
    public class branch
    {
        public int branchId { get; set; }
        public String branchName { get; set; }
        public branchAdress branchAdress { get; set; }
    }
}
